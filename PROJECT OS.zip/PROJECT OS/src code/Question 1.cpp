// Nur Afiqah binti Mohd Rosli 1910100
// Mastura binti Mohamad Rizal 1918378
// Nurharith Akma binti Harisa 1910110

#include <iostream>
#include <fstream>
#include <cstdlib>
using std::cerr;
using std::cout;
using std::endl;

using std::ifstream;
using std::basic_ifstream;

int main()
{
    cout<<"FCFS Disk Scheduling\n";

    int m , i=1;
    int n, start= 0;  
    int seek_count, head, cur_track, count=1;

    ifstream fin("Input Q1.txt");
    fin>>m>>n>>start;
    cout<<"Starting track: "<<start<<endl;

    while(m--)
    {
        seek_count=0;
        head=start;

    for(i=0; i<n; ++i)
    {
        fin>>cur_track;

        seek_count=seek_count+abs(cur_track-head);
        head=cur_track;
    }

        cout<<endl;
        cout<<"Case "<<count<<", Total: "<<seek_count<<endl;
        count++;
    }

        fin.close();

    return 0;
}