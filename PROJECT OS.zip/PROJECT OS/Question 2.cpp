// Nur Afiqah binti Mohd Rosli 1910100
// Mastura binti Mohamad Rizal 1918378
// Nurharith Akma binti Harisa 1910110


#include <bits/stdc++.h>
using namespace std;

int getFault(vector <int> page, int range)

    {
        unordered_set <int> x;
        unordered_map <int, int> indexes;
        int n = page.size();
        
        int page_fault = 0;
        for (int i = 0; i < n; i++)
       
        {
        if (x.size() < range)
            
            {
             if (x.find(page[i]) == x.end())
                
                {
                x.insert(page[i]);
                page_fault++;
                }
                
                indexes[page[i]] = i;
            }
        else
            {
                if (x.find(page[i]) == x.end())
                
                {
                    int lru = INT_MAX, val;
                    for (auto it=x.begin(); it!=x.end(); it++)
                
                {
                    if (indexes[*it] < lru)
                
                {
                    lru = indexes[*it];
                    val = *it;
                }
                }
                    x.erase(val);
                    x.insert(page[i]);
                    page_fault++;
                }
                    indexes[page[i]] = i;
            }
        }
        return page_fault;
    }
    
    
    // Driver code
    
    int main()
    
    {
        vector<int> page;
        int range, pageFault;
        string line, caseNo, word;
        fstream file;
        file.open("Input Q2.txt", ios :: in);
        
        while (!file.eof()) 
        {
            page.clear();
            pageFault = 0;
            getline(file, line);
            stringstream x(line);
        
            getline(x, word, ',');
            caseNo = word;
            getline(x, word, ',');
            range = stoi(word);
        
        while (getline(x, word, ',')) 
        {
            page.push_back(stoi(word));
        }
        
        //Print result;
            pageFault = getFault(page, range);
            cout << caseNo << ", " << pageFault << " faults " << endl;
        }
            file.close();
        
        return 0;
    }